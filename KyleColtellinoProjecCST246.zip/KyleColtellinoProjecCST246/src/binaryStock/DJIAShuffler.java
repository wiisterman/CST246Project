package binaryStock;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;

public class DJIAShuffler 
{
	public static void main(String[] args) throws FileNotFoundException 
	{
	
		Tree theTree = new Tree();
		ArrayList<String> thelist = new ArrayList<String>();
		ArrayList<String> datesList = new ArrayList<String>();
		ArrayList<String> priceList = new ArrayList<String>();
    	try {
			BufferedReader br = new BufferedReader(new FileReader("inputData/DJIA.txt"));
			 StringBuilder sb = new StringBuilder();
			 String line = br.readLine();

			    while (line != null) {
			        sb.append(line);
			        sb.append("\n");
			        line = br.readLine();
			        thelist.add(line);
			    }
			     
			}
    	catch (FileNotFoundException e1) {
			
			e1.printStackTrace();
		} catch (IOException e1) {
			
			e1.printStackTrace();
		}
    	String shuffled = "";
    	Collections.shuffle(thelist);
    	Collections.shuffle(thelist);
    	thelist.removeAll(Collections.singleton(null));
    	for(int i = 0; i < thelist.size(); i++)
    	{
    		shuffled += thelist.get(i) + " \n";
    	}
    	//System.out.println(shuffled);
		
    	try(  PrintWriter out = new PrintWriter( "inputData/shuffledDJIA.txt" )  )
    	{
		    out.println( shuffled.trim() );
		}
	}
}
