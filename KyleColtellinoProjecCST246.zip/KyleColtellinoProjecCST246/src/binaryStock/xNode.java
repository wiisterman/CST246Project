package binaryStock;

public class xNode 
{

	public int iData; //Stock Date 
	public String dData;//Stock Price (String for the ---)
	public xNode leftChild;
	public xNode rightChild;
	
	public xNode(int iData, String dData) {
		super();
		this.iData = iData;
		this.dData = dData;
		leftChild = null;
		rightChild = null;
	}
	
	public xNode()
	{
		
	}
	public void displayNode()
	{
		System.out.println(iData + ", " + dData + "\n");
	}
	
	
}
