package Project;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class DemoWithOutFX 
{
	public static void main(String[] args) throws IOException
	{
		// feed the generator a fixed random value for repeatable behavior
		Generate gen = new Generate(new Random(42));
		
		BufferedReader br = new BufferedReader(new FileReader("blowingInTheWind.txt"));
		String everything = " ";
		try {
		    StringBuilder sb = new StringBuilder();
		   String line = br.readLine();

		    while (line != null) {
		        sb.append(line);
		        sb.append("\n");
		        line = br.readLine();
		    }
		     everything = sb.toString();
		} finally {
		    br.close();
		}
		
		
		gen.addText(everything);
	
		System.out.println(gen.generateText(30));
	}
}
	
