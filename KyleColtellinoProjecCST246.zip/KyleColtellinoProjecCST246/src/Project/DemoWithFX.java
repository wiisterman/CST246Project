package Project;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;


public class DemoWithFX extends Application
{

	public void start(Stage primaryStage) 
	{
	
		  	primaryStage.setTitle("AutoFiller");
			GridPane database = new GridPane();
			database.setHgap(8);
			database.setVgap(8);
			database.setPadding(new Insets(20,20,20,20));
			
			GridPane autoFillPane = new GridPane();
			autoFillPane.setHgap(8);
			autoFillPane.setVgap(8);
			autoFillPane.setPadding(new Insets(20,20,20,20));
			
			TextArea textArea = new TextArea();
			textArea.setEditable(false);
			database.add(textArea, 0,0); 
			Button randWordBtn = new Button("Generate");
			database.add(randWordBtn, 0, 1);
			
			Label howManyWordsLbl = new Label("How many words to generate: ");
			TextField howManyWordsField = new TextField();
			database.add(howManyWordsLbl, 0,2); 
			database.add(howManyWordsField, 0,3); 
			
			Scene scene = new Scene(database, 500,250);
			primaryStage.setScene(scene);
			primaryStage.show();
	
			
			randWordBtn.setOnAction(new EventHandler<ActionEvent>()  
			{
			    @Override 
			    public void handle(ActionEvent e) 
			    {
			    	
			    	
			    	String everything = " ";
			    	Generate gen = new Generate(new Random(42));
			    	try {
						BufferedReader br = new BufferedReader(new FileReader("data/warAndPeace.txt"));
						 StringBuilder sb = new StringBuilder();
						   String line = br.readLine().replace(".", " ");

						    while (line != null) {
						        sb.append(line);
						        sb.append("\n");
						        line = br.readLine();
						    }
						     everything = sb.toString();
						}
			    	catch (FileNotFoundException e1) {
						
						e1.printStackTrace();
					} catch (IOException e1) {
						
						e1.printStackTrace();
					}
			    	
			    	gen.addText(everything);
			    	
			    	
			    	int howManyWords = Integer.parseInt(howManyWordsField.getText());
			    	textArea.setText(gen.generateText(howManyWords));
			    	
			    	
			    	try {
						PrintWriter out = new PrintWriter("output.txt");
						out.println(gen.generateText(howManyWords));
					} catch (FileNotFoundException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
			    }
			}
			);
			
			
	}
	
	 public static void main(String[] args) 
		{
			Application.launch(args);
		}
}
