package Project;

public interface ProjectInterface 
{

	public void addText(String sourceText);
	

	public String generateText(int numWords);
	
	
	public void reAdd(String sourceText);
	
}
