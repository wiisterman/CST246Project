package markovTextGen;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;

public class MarkovGenerator 
{


	private List<ListNode> wordList; 
	
	private String starter;
	
	private Random rnGenerator;
	
	public MarkovGenerator(Random generator)
	{
		wordList = new LinkedList<ListNode>();
		starter = "";
		rnGenerator = generator;
	}
	
	
	
	public void addText(String sourceText)
	{
		
		
		if (sourceText.length() == 0) {
			System.out.println();
		} else {
			String[] sourceWords = sourceText.split("[\\s]+");
			int size = sourceWords.length;
			
			starter = sourceWords[(int) (Math.random() * size)];
			String prevWord = starter;
			String w;
			ListNode node;
			for (int i = 1; i <= sourceWords.length; i++) {
				if (i == sourceWords.length) {
					w = sourceWords[0];
				} else {
					w = sourceWords[i];
				}
				
				node = findNode(prevWord);
				if (node == null) {
					node = new ListNode(prevWord);
					node.addNextWord(w);
					wordList.add(node);
				} else {
					node.addNextWord(w);
				}
				prevWord = w;
				
			}
		}
	}
	
	
	public String generateText(int numWords) {
	   
		String output = "";
		if (wordList.isEmpty()) {
			
			return output;
		}
		if (numWords == 0) {
			return output;
		}
		String currWord = starter;
		output = output + currWord;
		int count = 1;
		while (count < numWords) {
			ListNode node = findNode(currWord);
			String w = node.getRandomNextWord(rnGenerator);
			output = output + " " + w;
			currWord = w;
			count++;
		}
		String newOutput = output.replaceAll("((?:\\w+\\s){2}\\w+)(\\s)", "$1\n");
		return newOutput;
	}
	
	
	
	@Override
	public String toString()
	{
		String toReturn = "";
		for (ListNode n : wordList)
		{
			toReturn += n.toString();
		}
		return toReturn;
	}
	
	
	
	

	
	private ListNode findNode(String word) {
		for (ListNode node : wordList) {
			if (word.equals(node.getWord())) {
				return node;
			}
		}
		return null;
	}
	
}


class ListNode
{
    
	private String word;
	

	private List<String> nextWords;
	
	ListNode(String word)
	{
		this.word = word;
		nextWords = new LinkedList<String>();
	}
	
	public String getWord()
	{
		return word;
	}

	public void addNextWord(String nextWord)
	{
		nextWords.add(nextWord);
	}
	
	public String getRandomNextWord(Random generator)
	{
		int size = nextWords.size();
		int index = generator.nextInt(size);
	    return nextWords.get(index);
	}
	
}
