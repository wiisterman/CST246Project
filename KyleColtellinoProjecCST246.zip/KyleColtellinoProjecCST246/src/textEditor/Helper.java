package textEditor;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public abstract class Helper 
{

	
	private String text;
	
	
	public Helper(String text)
	{
		this.text = text;
	}
	
	

	public List<String> getTokens(String pattern)
	{
		
	
		ArrayList<String> tokens = new ArrayList<>();

		Pattern tokenSplitter = Pattern.compile(pattern);
		Matcher m = tokenSplitter.matcher(text);
		
		while(m.find())
		{
			tokens.add(m.group());
		}
		
		return tokens;
		
	}
	
	
	public abstract int getNumOfWords();
	
	public abstract int getNumOfSentences();
	
	public abstract int getNumOfSyl();
	
	
	
	public String getText()
	{
		return text;
	}
	
	
	 
	
	/*
	 * ASL = Average Sentence Length (i.e., the number of words divided by the number of sentences) 

ASW = Average number of syllables per word (i.e., the number of syllables divided by the number of words) 

	 */
	
	
}
