package textEditor;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class OneLoop 
{

	private String text;
	private double numOfWords = 0;
	private double numOfSentences = 0;
	private double numOfSyllables = 0;
	private double fleschScore = 0;
	ArrayList<String> syllablesA = new ArrayList<>();
	ArrayList<String> sentencesA = new ArrayList<>();
	ArrayList<String> wordsA = new ArrayList<>();
	long totalTime = 0;
	
	
	
	public OneLoop(String text)
	{
		this.text = text;
	}
	
	int i = 0;
	public void getTokens()
	{
		
		
		Pattern tokenSplitter = Pattern.compile("[aeiouy.!? ]");
		Pattern hasSentence = Pattern.compile("[?!.]");
		Pattern hasWord = Pattern.compile("[ ]");

		Matcher m = tokenSplitter.matcher(text);
		//finds the sentences which is the smallest out of the 3 
		//then words
		//then syllables
		while(m.find())
		{
		
			Matcher sentenceMatch = hasSentence.matcher(m.group());
			Matcher wordMatch = hasWord.matcher(m.group());
			
			
			
			if(sentenceMatch.find())
			{
				sentencesA.add(sentenceMatch.group());
			}
			
			else if(wordMatch.find())
			{
				wordsA.add(wordMatch.group());	
			}
			else
			{
				syllablesA.add("s");
			}
			
			
			
			
		}
		setNumOfSentences(sentencesA.size());
		setNumOfSyllables(syllablesA.size());
		setNumOfWords(wordsA.size());
	
	}
	

	public double getNumOfWords() {
		return numOfWords;
	}


	public void setNumOfWords(double numOfWords) {
		this.numOfWords = numOfWords;
	}


	public double getNumOfSentences() {
		return numOfSentences;
	}


	public void setNumOfSentences(double numOfSentences) {
		this.numOfSentences = numOfSentences;
	}


	public double getNumOfSyllables() {
		return numOfSyllables;
	}


	public void setNumOfSyllables(double numOfSyllables) {
		this.numOfSyllables = numOfSyllables;
	}


	public double getFleschScore() {
		double re = 0;
		double asl = getNumOfSyllables()/getNumOfWords();
		double asw = getNumOfWords()/getNumOfSentences();
		double x =  (84.6*(asl));
		double y = (1.015* (asw));
		double z = (206.835);
		double ex = z-y-x;
		
		return Math.round(ex);
	}


	public void setFleschScore(int fleschScore) {
		this.fleschScore = fleschScore;
	}


}

