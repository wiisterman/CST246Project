package textEditor;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class OneLoop 
{

	private String text;
	private int numOfWords = 0;
	private int numOfSentences = 0;
	private int numOfSyllables = 0;
	private double fleschScore = 0;
	
	
	
	public OneLoop(String text)
	{
		this.text = text;
	}

	public void getTokens()
	{
		
	
		ArrayList<String> tokens = new ArrayList<>();

		Pattern tokenSplitter = Pattern.compile(".");
		Matcher m = tokenSplitter.matcher(text);
		
		while(m.find())
		{
			
			if(m.group().equals(" "))
			{
				numOfWords++;
			}
			
			else if(m.group().equals(".") || m.group().equals("?") ||m.group().equals("!"))
			{
				numOfSentences++;
			}
			else if(m.group().equals("a") || m.group().equals("e") || m.group().equals("i")||
					m.group().equals("o")|| m.group().equals("u") ||m.group().equals("y"))
			{
				numOfSyllables++;
			}
			
		}
		setNumOfSentences(numOfSentences);
		setNumOfSyllables(numOfSyllables);
		setNumOfWords(numOfWords);
	}
	

	public int getNumOfWords() {
		return numOfWords;
	}


	public void setNumOfWords(int numOfWords) {
		this.numOfWords = numOfWords;
	}


	public int getNumOfSentences() {
		return numOfSentences;
	}


	public void setNumOfSentences(int numOfSentences) {
		this.numOfSentences = numOfSentences;
	}


	public int getNumOfSyllables() {
		return numOfSyllables;
	}


	public void setNumOfSyllables(int numOfSyllables) {
		this.numOfSyllables = numOfSyllables;
	}


	public double getFleschScore() {
		double re = 0;
		double asl = (getNumOfWords()/getNumOfSentences());
		double asw = (getNumOfSyllables()/getNumOfWords());
		double aslX = (1.015*asl);
		double aswX = (84.6*asw);
		re = ((206.835)-(aslX)-(aswX));
		
		return re;
	}


	public void setFleschScore(int fleschScore) {
		this.fleschScore = fleschScore;
	}
	
	
	
	
}

