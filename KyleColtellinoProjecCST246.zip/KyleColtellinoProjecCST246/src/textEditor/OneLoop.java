package textEditor;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class OneLoop 
{

	private String text;
	private double numOfWords = 0;
	private double numOfSentences = 0;
	private double numOfSyllables = 0;
	private double fleschScore = 0;
	ArrayList<String> syllablesA = new ArrayList<>();
	ArrayList<String> sentencesA = new ArrayList<>();
	
	public OneLoop(String text)
	{
		this.text = text;
	}
	
		
	public void getTokens()
	{
		Pattern hasAVowel = Pattern.compile( "[aeiouy]+[^$e(,.:;!?)]");
		Pattern tokenSplitter = Pattern.compile("[a-zA-Z]+.");
		Pattern hasSentence = Pattern.compile("[^?!.][?!.]");
		Matcher m = tokenSplitter.matcher(text);
		while(m.find())
		{
			Matcher vowelMatch =  hasAVowel.matcher(m.group());
			Matcher sentenceMatch = hasSentence.matcher(m.group());
			if(sentenceMatch.find())
			{
				sentencesA.add(sentenceMatch.group());
			}
			else if(vowelMatch.find())
			{
				syllablesA.add(vowelMatch.group());
			}
			
			numOfWords++;
		}
		setNumOfSentences(sentencesA.size());
		setNumOfSyllables(syllablesA.size());
		setNumOfWords(numOfWords);
	}
	

	public double getNumOfWords() {
		return numOfWords;
	}


	public void setNumOfWords(double numOfWords) {
		this.numOfWords = numOfWords;
	}


	public double getNumOfSentences() {
		return numOfSentences;
	}


	public void setNumOfSentences(double numOfSentences) {
		this.numOfSentences = numOfSentences;
	}


	public double getNumOfSyllables() {
		return numOfSyllables;
	}


	public void setNumOfSyllables(double numOfSyllables) {
		this.numOfSyllables = numOfSyllables;
	}


	public double getFleschScore() {
		double re = 0;
		double asl = getNumOfSyllables()/getNumOfWords();
		double asw = getNumOfWords()/getNumOfSentences();
		double x =  (84.6*(asl));
		double y = (1.015* (asw));
		double z = (206.835);
		return z-y-x;
	}


	public void setFleschScore(int fleschScore) {
		this.fleschScore = fleschScore;
	}
	
	
	
	
}

