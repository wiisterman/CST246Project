package textEditor;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

public class ProjectData 
{

	public static void main(String[] args) throws IOException 
	{
		
		BufferedReader br = new BufferedReader(new FileReader("data/warAndPeace.txt"));
		String everything = " ";
		try {
		    StringBuilder sb = new StringBuilder();
		   String line = br.readLine();

		    while (line != null) {
		        sb.append(line);
		        sb.append("\n");
		        line = br.readLine();
		    }
		     everything = sb.toString();
		} finally {
		    br.close();
		}
		
		WayOne way1 = new WayOne(everything);
		
		int words = way1.getEveryThing();
		int tenP = (int) (words *.10); 		
		int twentP = (int) (words *.20); 	
		int thirtP = (int) (words *.30); 	
		int fourtP = (int) (words *.40); 	
		int fiftP = (int) (words *.50); 	
		int sixtP = (int) (words *.60); 		
		int seventP = (int) (words *.70); 	
		int eightP = (int) (words *.80); 	
		int nintP = (int) (words *.90); 	
		int hundrP = (int) (words); 	
	
		
		if (words > tenP)
		{
			String tenPWord = everything.substring(0, tenP);
			try(  PrintWriter out = new PrintWriter( "inputData/10PercentWAP.txt" )  ){
			    out.println( tenPWord );
			}
		}
	
		if (words > twentP)
		{
			String twentPWord = everything.substring(0, twentP);
			try(  PrintWriter out = new PrintWriter( "inputData/20PercentWAP.txt" )  ){
			    out.println( twentPWord );
			}
		}
		if (words > thirtP)
		{
			String thirtPWord = everything.substring(0, thirtP);
			try(  PrintWriter out = new PrintWriter( "inputData/30PercentWAP.txt" )  ){
			    out.println( thirtPWord );
			}
		}
		if (words > fourtP)
		{
			String fourtPWord = everything.substring(0, fourtP);
			try(  PrintWriter out = new PrintWriter( "inputData/40PercentWAP.txt" )  ){
			    out.println( fourtPWord );
			}
		}
		if (words > fiftP)
		{
			String fiftPWord = everything.substring(0, fiftP);
			try(  PrintWriter out = new PrintWriter( "inputData/50PercentWAP.txt" )  ){
			    out.println( fiftPWord );
			}
		}
		
		if (words > sixtP)
		{
			String sixtPWord = everything.substring(0, sixtP);
			try(  PrintWriter out = new PrintWriter( "inputData/60PercentWAP.txt" )  ){
			    out.println( sixtPWord );
			}
		}
	
		if (words > seventP)
		{
			String seventPWord = everything.substring(0, seventP);
			try(  PrintWriter out = new PrintWriter( "inputData/70PercentWAP.txt" )  ){
			    out.println( seventPWord );
			}
		}
		if (words > eightP)
		{
			String eightPWord = everything.substring(0, eightP);
			try(  PrintWriter out = new PrintWriter( "inputData/80PercentWAP.txt" )  ){
			    out.println( eightPWord );
			}
		}
		if (words > nintP)
		{
			String nintPWord = everything.substring(0, nintP);
			try(  PrintWriter out = new PrintWriter( "inputData/90PercentWAP.txt" )  ){
			    out.println( nintPWord );
			}
		}
		if (words > hundrP)
		{
			String hundrPWord = everything.substring(0, hundrP);
			try(  PrintWriter out = new PrintWriter( "inputData/100PercentWAP.txt" )  ){
			    out.println(hundrPWord);
			}
		}
		
		System.out.println("Done");
		
		/*
		System.out.println(tenP);
		System.out.println(twentP);
		System.out.println(thirtP);
		System.out.println(fourtP);
		System.out.println(fiftP);
		System.out.println(sixtP);
		System.out.println(seventP);
		System.out.println(eightP);
		System.out.println(nintP);
		System.out.println(hundrP);
		*/	
		
		
		
		
	}
	
	
	
}
