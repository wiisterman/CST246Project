package textEditor;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class ProjectData 
{

	public static void main(String[] args) throws IOException 
	{
		//Read and save the whole textFile
		BufferedReader br = new BufferedReader(new FileReader("data/warAndPeace.txt"));
		String everything = " ";
		try {
		    StringBuilder sb = new StringBuilder();
		   String line = br.readLine();

		    while (line != null) {
		        sb.append(line);
		        sb.append("\n");
		        line = br.readLine();
		    }
		     everything = sb.toString();
		} finally {
		    br.close();
		}
		
		WayOne way1 = new WayOne(everything);
		
		//get the total number of everything and separate it by percentage
		List<String> words = way1.getWordStr();
		//String newBook = "";
		System.out.println("Starting String saving");
		//space the words because I was getting words that weren't seperated
		
		StringBuilder newBook = new StringBuilder();
		for (String s : words)
		{
			newBook.append(s);
			newBook.append(" ");
		}
		//removed the double spaces
		String newBook2 = newBook.toString();
		newBook2 = newBook2.replaceAll("\\s+", " ");
		System.out.println("Done Saving");
		
		//10%...20%...30%...
		
		int tenP = (int) (newBook2.length() *.10); 	
		int twentP = (int) (newBook2.length() *.20); 	
		int thirtP = (int) (newBook2.length() *.30); 	
		int fourtP = (int) (newBook2.length() *.40); 	
		int fiftP = (int) (newBook2.length() *.50); 	
		int sixtP = (int) (newBook2.length() *.60); 		
		int seventP = (int) (newBook2.length() *.70); 	
		int eightP = (int) (newBook2.length() *.80); 	
		int nintP = (int) (newBook2.length() *.90); 	
		int hundrP = (int) (newBook2.length()); 	
	
		//Save them all
		
		if (newBook2.length() > tenP)
		{
			//keep adding on from the beginning
			String tenPWord = newBook2.substring(0, tenP);
			try(  PrintWriter out = new PrintWriter( "inputData/10PercentWAP.txt" )  ){
			    out.println( tenPWord );
			}
		}
	
		if (newBook2.length() > twentP)
		{
			String twentPWord = newBook2.substring(0, twentP);
			try(  PrintWriter out = new PrintWriter( "inputData/20PercentWAP.txt" )  ){
			    out.println( twentPWord );
			}
		}
		if (newBook2.length() > thirtP)
		{
			String thirtPWord = newBook2.substring(0, thirtP);
			try(  PrintWriter out = new PrintWriter( "inputData/30PercentWAP.txt" )  ){
			    out.println( thirtPWord );
			}
		}
		if (newBook2.length() > fourtP)
		{
			String fourtPWord = newBook2.substring(0, fourtP);
			try(  PrintWriter out = new PrintWriter( "inputData/40PercentWAP.txt" )  ){
			    out.println( fourtPWord );
			}
		}
		if (newBook2.length() > fiftP)
		{
			String fiftPWord = newBook2.substring(0, fiftP);
			try(  PrintWriter out = new PrintWriter( "inputData/50PercentWAP.txt" )  ){
			    out.println( fiftPWord );
			}
		}
		
		if (newBook2.length() > sixtP)
		{
			String sixtPWord = newBook2.substring(0, sixtP);
			try(  PrintWriter out = new PrintWriter( "inputData/60PercentWAP.txt" )  ){
			    out.println( sixtPWord );
			}
		}
	
		if (newBook2.length() > seventP)
		{
			String seventPWord = newBook2.substring(0, seventP);
			try(  PrintWriter out = new PrintWriter( "inputData/70PercentWAP.txt" )  ){
			    out.println( seventPWord );
			}
		}
		if (newBook2.length() > eightP)
		{
			String eightPWord = newBook2.substring(0, eightP);
			try(  PrintWriter out = new PrintWriter( "inputData/80PercentWAP.txt" )  ){
			    out.println( eightPWord );
			}
		}
		if (newBook2.length() > nintP)
		{
			String nintPWord = newBook2.substring(0, nintP);
			try(  PrintWriter out = new PrintWriter( "inputData/90PercentWAP.txt" )  ){
			    out.println( nintPWord );
			}
		}
		//The Whole file
		if (newBook2.length() == hundrP)
		{
				try(  PrintWriter out = new PrintWriter( "inputData/100PercentWAP.txt" )  ){
			    out.println(newBook2);
			}
		}
		
		System.out.println("Done");
		
		
	}
	
	

}
