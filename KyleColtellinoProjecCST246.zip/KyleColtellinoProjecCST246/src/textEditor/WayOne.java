package textEditor;

import java.util.ArrayList;
import java.util.List;

public class WayOne extends Helper
{

	public WayOne(String text) 
	{
		super(text);
		// TODO Auto-generated constructor stub
	}

	@Override
	public int getNumOfWords() {
		List<String> numOfS = new ArrayList<>();
		
		numOfS  = 	getTokens("(\\w+)");
		return numOfS.size();
	}

	@Override
	public int getNumOfSentences() {
		
		List<String> numOfS = new ArrayList<>();
		
		numOfS  = 	getTokens("[^?!.][?!.]");
		if(numOfS.size() == 0)
		{
			System.out.println("No Sentences");
		}
		return numOfS.size();
	}

	@Override
	public int getNumOfSyl() {
		List<String> numOfS = new ArrayList<>();
		
		numOfS  = 	getTokens("[aeiouy]+[^$e(,.:;!?)]");
		return numOfS.size();
	}
//RE = 206.835 � (1.015 x ASL) � (84.6 x ASW
	public double getFleschScore()
	{
		double re = 0;
		double asl = (getNumOfWords()/getNumOfSentences());
		double asw = (getNumOfSyl()/getNumOfWords());
		double aslX = (1.015*asl);
		double aswX = (84.6*asw);
		re = ((206.835)-(aslX)-(aswX));
		
		return re;
	}
	
	 public String getTextDescription() {
	        double index = (double) getFleschScore();
	        if (index >= 100) {
	            return "The text is very easy to read.";
	        } else if (index >= 80) {
	            return "The text is quite easy to read.";
	        } else if (index >= 60) {
	            return "The text is moderately easy to read.";
	        } else if (index >= 40) {
	            return "The text is not particularly easy to read.";
	        } else if (index >= 20) {
	            return "The text is of university level difficulty";
	        } else {
	            return "The document is almost impenetrable.";
	        }
	    }

	public int getEveryThing() {
		List<String> numOfS = new ArrayList<>();
		
		numOfS  = 	getTokens(".");
		return numOfS.size();
		
	}
	
}
