package textEditor;

import java.util.ArrayList;
import java.util.List;

public class WayOne extends Helper
{

	public WayOne(String text) 
	{
		super(text);
		// TODO Auto-generated constructor stub
	}

	@Override
	public double getNumOfWords() {
		List<String> numOfS = new ArrayList<>();
		
		numOfS  = 	getTokens("('\\w+)|(\\w+'\\w+)|(\\w+')|(\\w+)");
		return numOfS.size();
	}

	@Override
	public double getNumOfSentences() {
		
		List<String> numOfS = new ArrayList<>();
		
		numOfS  = 	getTokens("[?!.]");
		
		return numOfS.size();
	}

	@Override
	public double getNumOfSyl() {
		List<String> numOfS = new ArrayList<>();
		
		numOfS  = 	getTokens("[aeiouy]");
		return numOfS.size();
	}

	//Flesch Formula
	//RE = 206.835 � (1.015 x ASL) � (84.6 x ASW
	public double getFleschScore()
	{
		double re = 0;
		double asl = (getNumOfWords()/getNumOfSentences());
		double asw = (getNumOfSyl()/getNumOfWords());
		re =  206.835 - (1.015* asl) - (84.6*asw);
		
		return Math.round(re);
	}
	
	
	
	public  List<String> getWordStr() {
		List<String> numOfS = new ArrayList<>();
		
		numOfS  = 	getTokens("[A-Za-z]+.");
		return numOfS;
		
	}
	
}
