package textEditor;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class DemoNoFX 
{

	public static void main(String[] args) throws IOException 
	{
		String tenPS = "";
    	try {
			BufferedReader br = new BufferedReader(new FileReader("data/10PercentWAP.txt"));
			 StringBuilder sb = new StringBuilder();
			   String line = br.readLine();
			    while (line != null) {
			        sb.append(line);
			        sb.append("\n");
			        line = br.readLine();
			    }
			    tenPS = sb.toString();
			}
    	catch (FileNotFoundException e1) {
			
			e1.printStackTrace();
		} catch (IOException e1) {
			
			e1.printStackTrace();
		}
    	String twentyPS = "";
    	try {
			BufferedReader br = new BufferedReader(new FileReader("data/20PercentWAP.txt"));
			 StringBuilder sb = new StringBuilder();
			   String line = br.readLine();
			    while (line != null) {
			        sb.append(line);
			        sb.append("\n");
			        line = br.readLine();
			    }
			    twentyPS = sb.toString();
			}
    	catch (FileNotFoundException e1) {
			
			e1.printStackTrace();
		} catch (IOException e1) {
			
			e1.printStackTrace();
		}
    	String thirtyPS = "";
    	try {
			BufferedReader br = new BufferedReader(new FileReader("data/30PercentWAP.txt"));
			 StringBuilder sb = new StringBuilder();
			   String line = br.readLine();
			    while (line != null) {
			        sb.append(line);
			        sb.append("\n");
			        line = br.readLine();
			    }
			    thirtyPS = sb.toString();
			}
    	catch (FileNotFoundException e1) {
			
			e1.printStackTrace();
		} catch (IOException e1) {
			
			e1.printStackTrace();
		}
    	String fourtyPS = "";
    	try {
			BufferedReader br = new BufferedReader(new FileReader("data/40PercentWAP.txt"));
			 StringBuilder sb = new StringBuilder();
			   String line = br.readLine();
			    while (line != null) {
			        sb.append(line);
			        sb.append("\n");
			        line = br.readLine();
			    }
			    fourtyPS = sb.toString();
			}
    	catch (FileNotFoundException e1) {
			
			e1.printStackTrace();
		} catch (IOException e1) {
			
			e1.printStackTrace();
		}
    	String fiftyPS = "";
    	try {
			BufferedReader br = new BufferedReader(new FileReader("data/50PercentWAP.txt"));
			 StringBuilder sb = new StringBuilder();
			   String line = br.readLine();
			    while (line != null) {
			        sb.append(line);
			        sb.append("\n");
			        line = br.readLine();
			    }
			    fiftyPS = sb.toString();
			}
    	catch (FileNotFoundException e1) {
			
			e1.printStackTrace();
		} catch (IOException e1) {
			
			e1.printStackTrace();
		}
    	String sixtyPS = "";
    	try {
			BufferedReader br = new BufferedReader(new FileReader("data/60PercentWAP.txt"));
			 StringBuilder sb = new StringBuilder();
			   String line = br.readLine();
			    while (line != null) {
			        sb.append(line);
			        sb.append("\n");
			        line = br.readLine();
			    }
			    sixtyPS = sb.toString();
			}
    	catch (FileNotFoundException e1) {
			
			e1.printStackTrace();
		} catch (IOException e1) {
			
			e1.printStackTrace();
		}
    	String seventyPS = "";
    	try {
			BufferedReader br = new BufferedReader(new FileReader("data/70PercentWAP.txt"));
			 StringBuilder sb = new StringBuilder();
			   String line = br.readLine();
			    while (line != null) {
			        sb.append(line);
			        sb.append("\n");
			        line = br.readLine();
			    }
			    seventyPS = sb.toString();
			}
    	catch (FileNotFoundException e1) {
			
			e1.printStackTrace();
		} catch (IOException e1) {
			
			e1.printStackTrace();
		}
    	String eightyPS = "";
    	try {
			BufferedReader br = new BufferedReader(new FileReader("data/80PercentWAP.txt"));
			 StringBuilder sb = new StringBuilder();
			   String line = br.readLine();
			    while (line != null) {
			        sb.append(line);
			        sb.append("\n");
			        line = br.readLine();
			    }
			    eightyPS = sb.toString();
			}
    	catch (FileNotFoundException e1) {
			
			e1.printStackTrace();
		} catch (IOException e1) {
			
			e1.printStackTrace();
		}
    	String ninetyPS = "";
    	try {
			BufferedReader br = new BufferedReader(new FileReader("data/90PercentWAP.txt"));
			 StringBuilder sb = new StringBuilder();
			   String line = br.readLine();
			    while (line != null) {
			        sb.append(line);
			        sb.append("\n");
			        line = br.readLine();
			    }
			    ninetyPS = sb.toString();
			}
    	catch (FileNotFoundException e1) {
			
			e1.printStackTrace();
		} catch (IOException e1) {
			
			e1.printStackTrace();
		}
    	String hundredPS = "";
    	try {
			BufferedReader br = new BufferedReader(new FileReader("data/warAndpeace.txt"));
			 StringBuilder sb = new StringBuilder();
			   String line = br.readLine();
			    while (line != null) {
			        sb.append(line);
			        sb.append("\n");
			        line = br.readLine();
			    }
			    hundredPS = sb.toString();
			}
    	catch (FileNotFoundException e1) {
			
			e1.printStackTrace();
		} catch (IOException e1) {
			
			e1.printStackTrace();
		}
    	
    	WayOne file1 = new WayOne(tenPS);
    	WayOne file2 = new WayOne(twentyPS);
    	WayOne file3 = new WayOne(thirtyPS);
    	WayOne file4 = new WayOne(fourtyPS);
    	WayOne file5 = new WayOne(fiftyPS);
    	WayOne file6 = new WayOne(sixtyPS);
    	WayOne file7 = new WayOne(seventyPS);
    	WayOne file8 = new WayOne(eightyPS);
    	WayOne file9 = new WayOne(ninetyPS);
    	WayOne file10 = new WayOne(hundredPS);
    	
    	
    	System.out.println("Sentences: " + file1.getNumOfSentences());
		System.out.println("Syllables: " + file1.getNumOfSyl());
		System.out.println("Words: "+ file1.getNumOfWords());
		System.out.println();
    	
		System.out.println("Sentences: " + file2.getNumOfSentences());
		System.out.println("Syllables: " + file2.getNumOfSyl());
		System.out.println("Words: "+ file2.getNumOfWords());
		System.out.println();
    	
		System.out.println("Sentences: " + file3.getNumOfSentences());
		System.out.println("Syllables: " + file3.getNumOfSyl());
		System.out.println("Words: "+ file3.getNumOfWords());
		System.out.println();
    	
		System.out.println("Sentences: " + file4.getNumOfSentences());
		System.out.println("Syllables: " + file4.getNumOfSyl());
		System.out.println("Words: "+ file4.getNumOfWords());
		System.out.println();
    	
		System.out.println("Sentences: " + file5.getNumOfSentences());
		System.out.println("Syllables: " + file5.getNumOfSyl());
		System.out.println("Words: "+ file5.getNumOfWords());
		System.out.println();
    	
		System.out.println("Sentences: " + file6.getNumOfSentences());
		System.out.println("Syllables: " + file6.getNumOfSyl());
		System.out.println("Words: "+ file6.getNumOfWords());
		System.out.println();

		System.out.println("Sentences: " + file7.getNumOfSentences());
		System.out.println("Syllables: " + file7.getNumOfSyl());
		System.out.println("Words: "+ file7.getNumOfWords());
		System.out.println();
		
		System.out.println("Sentences: " + file8.getNumOfSentences());
		System.out.println("Syllables: " + file8.getNumOfSyl());
		System.out.println("Words: "+ file8.getNumOfWords());
		System.out.println();

		System.out.println("Sentences: " + file9.getNumOfSentences());
		System.out.println("Syllables: " + file9.getNumOfSyl());
		System.out.println("Words: "+ file9.getNumOfWords());
		System.out.println();
    	
		System.out.println("Sentences: " + file10.getNumOfSentences());
		System.out.println("Syllables: " + file10.getNumOfSyl());
		System.out.println("Words: "+ file10.getNumOfWords());
		System.out.println();
    	
	}
	
	/*
	 * System.out.println(way1.getNumOfSentences());
		System.out.println(way1.getNumOfSyl());
		System.out.println(way1.getNumOfWords());
		System.out.println();
		
	System.out.println(way1.getTextDescription());
	long endTime   = System.currentTimeMillis();
	long totalTime = endTime - startTime;
	System.out.println(totalTime);
	 */
	
}
