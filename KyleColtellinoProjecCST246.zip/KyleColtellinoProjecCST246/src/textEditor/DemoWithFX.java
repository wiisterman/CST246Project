package textEditor;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import Project.Generate;
import javafx.animation.Animation.Status;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.CheckMenuItem;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class DemoWithFX extends Application
{

	String fileN = null;
	ArrayList<String> multFile = new ArrayList<>();
	ArrayList<Long> timeArray = new ArrayList<>();
	ArrayList<Long> timeArray2 = new ArrayList<>();
	public void start(Stage primaryStage) 
	{
	
		  	primaryStage.setTitle("Flesch Score");
			GridPane database = new GridPane();
			database.setHgap(8);
			database.setVgap(8);
			database.setPadding(new Insets(20,20,20,20));
			final FileChooser fileChooser = new FileChooser();
			 FileChooser.ExtensionFilter extFilter = 
                     new FileChooser.ExtensionFilter("TEXT files (*.txt)", "*.txt");
             fileChooser.getExtensionFilters().add(extFilter);
  
			Menu fileMenu = new Menu("File");
			   MenuItem newMenuItem = new MenuItem("New");
			   MenuItem openMenuItem = new MenuItem("Open");
			   MenuItem clearArrayMenuItem = new MenuItem("Clear Array");
			   MenuItem saveCountMenuItem = new MenuItem("Save Counts");
			   MenuItem save2MenuItem = new MenuItem("Save Text");
			   MenuItem exitMenuItem = new MenuItem("Exit");
			   fileMenu.getItems().addAll(newMenuItem, openMenuItem,saveCountMenuItem,save2MenuItem,clearArrayMenuItem,
			   new SeparatorMenuItem(), exitMenuItem);

			Menu editMenu = new Menu("Edit");
			   MenuItem wordMenuItem = new MenuItem("Words");
			   MenuItem syllableMenuItem = new MenuItem("Syllalbles");
			   MenuItem sentencesMenuItem = new MenuItem("Senteces");
			   MenuItem fleschMenuItem = new MenuItem("Flesch Score");  
			
			   editMenu.getItems().addAll(wordMenuItem, syllableMenuItem,sentencesMenuItem,
					   new SeparatorMenuItem(), fleschMenuItem);   
			   
			MenuBar menuBar = new MenuBar();
			menuBar.getMenus().addAll(fileMenu, editMenu);
			
			GridPane autoFillPane = new GridPane();
			autoFillPane.setHgap(8);
			autoFillPane.setVgap(8);
			autoFillPane.setPadding(new Insets(20,20,20,20));
			
			TextArea textArea = new TextArea();
			textArea.setEditable(false);
			database.add(textArea, 0,1); 
			Button analyze1 = new Button("Analyze 1");
			Button showGraph = new Button("Graph");
			Button analyze2 = new Button("Analyze 2");
			ProgressBar pb = new ProgressBar(0);
			TextField wordField = new TextField();
			wordField.setEditable(false);
			TextField sentenceField = new TextField();
			sentenceField.setEditable(false);
			TextField syllableField = new TextField();
			syllableField.setEditable(false);
			TextField fleschField = new TextField();
			fleschField.setEditable(false);
			database.add(showGraph, 0, 3);
			database.add(analyze1, 0,2);
			database.add(analyze2, 0, 4);
			database.add(menuBar, 0, 0);
	        database.add(wordField, 0, 5);
	        database.add(sentenceField, 0, 6);
	        database.add(syllableField, 0, 7);
	        database.add(fleschField, 0, 8);
			
			////////////////
			
		        //defining the axes
		        final NumberAxis xAxis = new NumberAxis();
		        final NumberAxis yAxis = new NumberAxis();
		        xAxis.setLabel("Percentage");
		        //creating the chart
		        final LineChart<Number,Number> lineChart = 
		                new LineChart<Number,Number>(xAxis,yAxis);
		                
		        lineChart.setTitle("Big-O");
		        //defining a series
		        XYChart.Series threeLoopData = new XYChart.Series();
		        XYChart.Series oneLoopData = new XYChart.Series();
		        threeLoopData.setName("Three Loops");
		        oneLoopData.setName("One Loop");
		     
			////////////////
		        lineChart.getData().addAll(oneLoopData,threeLoopData);
		        Scene graphS = new Scene(lineChart,500,250);
		        Scene scene = new Scene(database, 500,450);
				primaryStage.setScene(scene);
				primaryStage.show();
			
			exitMenuItem.setOnAction(actionEvent -> Platform.exit());
			newMenuItem.setOnAction(actionEvent -> textArea.clear());
			clearArrayMenuItem.setOnAction(actionEvent -> multFile.clear());
			save2MenuItem.setOnAction(new EventHandler<ActionEvent>()  
			{
			    @Override 
			    public void handle(ActionEvent e) 
			    {
			    	
			    	try(  PrintWriter out = new PrintWriter( "output/textArea.txt" )  ){
					    out.println( textArea.getText() );
					} catch (FileNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
			    }
			}
			);
			
			openMenuItem.setOnAction(
			            new EventHandler<ActionEvent>() {
			                @Override
			                public void handle(final ActionEvent e) {
			                    List<File> list =
			                        fileChooser.showOpenMultipleDialog(primaryStage);
			                    if (list != null) {
			                        for (int k = 0; k < list.size(); k++) {
			                        	multFile.add(list.get(k).getName());
			                        }
			                    }
			                }
			            });
			
			
			
			analyze1.setOnAction(new EventHandler<ActionEvent>()  
			{
			    @Override 
			    public void handle(ActionEvent e) 
			    {
			    	
			    	for(int i = 0; i < multFile.size(); i++)
			    	{
			    		String everything = "";
			    	try {
						BufferedReader br = new BufferedReader(new FileReader("inputData/"+multFile.get(i)));
						 StringBuilder sb = new StringBuilder();
						   String line = br.readLine();
						    while (line != null) {
						        sb.append(line);
						        sb.append("\n");
						        line = br.readLine();
						    }
						    everything = sb.toString();
						}
			    	catch (FileNotFoundException e1) {
						
						e1.printStackTrace();
					} catch (IOException e1) {
						
						e1.printStackTrace();
					}
			    	
			    	WayOne file1 = new WayOne(everything);
			    	long startTime = System.currentTimeMillis();
			    	textArea.appendText("\nWords: " + file1.getNumOfWords()+
			    			"\nSentences: " + file1.getNumOfSentences()
			    			+ "\nSyllables: " + file1.getNumOfSyl()+ 
			    			"\nFlesch Score: " + file1.getFleschScore()+ "\n");
			    	long endTime   = System.currentTimeMillis();
					long totalTime = endTime - startTime;
					timeArray.add(totalTime);
					textArea.appendText(totalTime+"\n");
					wordField.appendText(Integer.toString(file1.getNumOfWords())+" ");
					sentenceField.appendText(Integer.toString(file1.getNumOfSentences())+" ");
					syllableField.appendText(Integer.toString(file1.getNumOfSyl())+" ");
					fleschField.appendText(Double.toString(file1.getFleschScore())+" ");
			    	}
			    }
			}
			);
			
			wordMenuItem.setOnAction(new EventHandler<ActionEvent>()  
			{
			    @Override 
			    public void handle(ActionEvent e) 
			    {
			    	
			    	textArea.setText(wordField.getText() + "\n");
			    }
			}
			);
			
			sentencesMenuItem.setOnAction(new EventHandler<ActionEvent>()  
			{
			    @Override 
			    public void handle(ActionEvent e) 
			    {
			    	
			    	textArea.setText(sentenceField.getText() + "\n");
			    }
			}
			);
			
			syllableMenuItem.setOnAction(new EventHandler<ActionEvent>()  
			{
			    @Override 
			    public void handle(ActionEvent e) 
			    {
			    	
			    	textArea.setText(syllableField.getText() + "\n");
			    }
			}
			);
			
			fleschMenuItem.setOnAction(new EventHandler<ActionEvent>()  
			{
			    @Override 
			    public void handle(ActionEvent e) 
			    {
			    	
			    	textArea.setText(fleschField.getText() + "\n");
			    }
			}
			);
		
			
			showGraph.setOnAction(new EventHandler<ActionEvent>() {
		        @Override
		        public void handle(ActionEvent t) 
		        {
		        	if(timeArray.isEmpty())
		        	{
		        		textArea.appendText("\nNo Data Analyze First\n");
		        	}
		        	else
		        	{primaryStage.setScene(graphS);
		        	
		        	int i = 0;
				        while(i < timeArray.size())
				        {
				        	threeLoopData.getData().add(new XYChart.Data(i,timeArray.get(i)));
				        	oneLoopData.getData().add(new XYChart.Data(i,timeArray2.get(i)));
				        i++;
				        
				        } 
		        	}//end action
		    }});
			
			saveCountMenuItem.setOnAction(new EventHandler<ActionEvent>()  
			{
			    @Override 
			    public void handle(ActionEvent e) 
			    {
			    	
			    	 
					    	
					    	try(  PrintWriter out = new PrintWriter( "output/results.txt" )  ){
							    out.println(wordField.getText() + "\n"+  sentenceField.getText() + "\n"
							    		+syllableField.getText() + "\n" + fleschField.getText() + "\n");
							} catch (FileNotFoundException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
					    
					}
			    	
			    
			}
			);
			
			analyze2.setOnAction(new EventHandler<ActionEvent>()  
			{
			    @Override 
			    public void handle(ActionEvent e) 
			    {
			    	
			    	for(int i = 0; i < multFile.size(); i++)
			    	{
			    		String everything = "";
			    	try {
						BufferedReader br = new BufferedReader(new FileReader("inputData/"+multFile.get(i)));
						 StringBuilder sb = new StringBuilder();
						   String line = br.readLine();
						    while (line != null) {
						        sb.append(line);
						        sb.append("\n");
						        line = br.readLine();
						    }
						    everything = sb.toString();
						}
			    	catch (FileNotFoundException e1) {
						
						e1.printStackTrace();
					} catch (IOException e1) {
						
						e1.printStackTrace();
					}
			    	
			    	OneLoop file1 = new OneLoop(everything);
			    	long startTime = System.currentTimeMillis();
			    	file1.getTokens();
			    	long endTime   = System.currentTimeMillis();
					long totalTime = endTime - startTime;
					timeArray2.add(totalTime);
			    	textArea.appendText("\nWords: " + file1.getNumOfWords()+
			    			"\nSentences: " + file1.getNumOfSentences()
			    			+ "\nSyllables: " + file1.getNumOfSyllables()+ 
			    			"\nFlesch Score: " + file1.getFleschScore()+ "\n" + totalTime + "\n");
			    	
			    	
			    	
					wordField.appendText(Integer.toString(file1.getNumOfWords())+" ");
					sentenceField.appendText(Integer.toString(file1.getNumOfSentences())+" ");
					syllableField.appendText(Integer.toString(file1.getNumOfSyllables())+" ");
					fleschField.appendText(Double.toString(file1.getFleschScore())+" ");
			    	}
			    }
			}
			);
			
	}
	
	
	
	 public static void main(String[] args) 
		{
			Application.launch(args);
		}
}
