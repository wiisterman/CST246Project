package textEditor;
/**
 * @author Kyle Coltellino
 * CST246 Final Project
 */
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Random;

import binaryStock.Tree;
import binaryStock.xNode;
import javafx.animation.Animation.Status;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.CheckMenuItem;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.GridPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import markovTextGen.MarkovGenerator;

public class DemoWithFX extends Application
{

	String fileN = null;
	ArrayList<String> multFile = new ArrayList<>();
	ArrayList<Long> timeArray = new ArrayList<>();
	ArrayList<Long> timeArray2 = new ArrayList<>();
	int xScale = 10;
	static Tree theTree = new Tree();
	long finalT = 0;
	long finalT2 = 0;
	ArrayList<Long> timeArray3 = new ArrayList<>();
	static Hashtable< Integer, String > hash = new Hashtable< Integer, String >();

	public void start(Stage primaryStage) 
	{
	
		  	primaryStage.setTitle("Flesch Score");
			GridPane database = new GridPane();
			database.setHgap(8);
			database.setVgap(8);
			database.setPadding(new Insets(20,20,20,20));
			final FileChooser fileChooser = new FileChooser();
			FileChooser.ExtensionFilter extFilter = 
            new FileChooser.ExtensionFilter("TEXT files (*.txt)", "*.txt");
            fileChooser.getExtensionFilters().add(extFilter);
            File defaultDirectory = new File("InputData");
            fileChooser.setInitialDirectory(defaultDirectory);
            
  
			Menu fileMenu = new Menu("File");
			   MenuItem newMenuItem = new MenuItem("New");
			   MenuItem openMenuItem = new MenuItem("Open");
			   MenuItem clearArrayMenuItem = new MenuItem("Clear Array");
			   MenuItem saveCountMenuItem = new MenuItem("Save Counts");
			   MenuItem save2MenuItem = new MenuItem("Save Text");
			   MenuItem exitMenuItem = new MenuItem("Exit");
			   fileMenu.getItems().addAll(newMenuItem, openMenuItem,saveCountMenuItem,save2MenuItem,
			   new SeparatorMenuItem(), exitMenuItem);

			//Menu
			Menu editMenu = new Menu("Edit");
			   MenuItem wordMenuItem = new MenuItem("Words");
			   MenuItem syllableMenuItem = new MenuItem("Syllalbles");
			   MenuItem sentencesMenuItem = new MenuItem("Senteces");
			   MenuItem fleschMenuItem = new MenuItem("Flesch Score");  
			
			   editMenu.getItems().addAll(wordMenuItem, syllableMenuItem,sentencesMenuItem,
					   new SeparatorMenuItem(), fleschMenuItem);   
			
			Menu markovGenMenu = new Menu("Generate");  
			
			MenuItem saveMenuItem = new MenuItem("Save");   
			markovGenMenu.getItems().addAll(saveMenuItem);
			
			
			
			
			MenuBar menuBar = new MenuBar();
			menuBar.getMenus().addAll(fileMenu, editMenu,markovGenMenu);
			//
			
			
			GridPane autoFillPane = new GridPane();
			autoFillPane.setHgap(8);
			autoFillPane.setVgap(8);
			autoFillPane.setPadding(new Insets(20,20,20,20));
			
			//All the GridPane stuff
			/**
			 * Load the Dictionary @ Startup
			 * Load the DJIA @ Startup
			 */
			loadHash();
			loadTree();
			//
			TextArea textArea = new TextArea();
			textArea.setEditable(false);
			database.add(textArea, 0,1); 
			Button analyze1 = new Button("Three Loops");
			Button showGraph = new Button("Graph");
			Button analyze2 = new Button("One Loop");
			Label wordLbl = new Label("Words:");
			TextField wordField = new TextField();
			wordField.setPromptText("Words");
			wordField.setEditable(false);
			Label sentenceLbl = new Label("Sentences:");
			TextField sentenceField = new TextField();
			sentenceField.setPromptText("Sentences");
			sentenceField.setEditable(false);
			Label syllableLbl = new Label("Syllables:");
			TextField syllableField = new TextField();
			syllableField.setPromptText("Syllables");
			syllableField.setEditable(false);
			Label fleschLbl = new Label("Flesch Index:");
			TextField fleschField = new TextField();
			fleschField.setPromptText("Flesch Index");
			fleschField.setEditable(false);
			TextField wordNumTextField = new TextField();
			wordNumTextField.setPromptText("How Many Words To Generate");
			TextField dateField = new TextField();
			dateField.setPromptText("YYYYMMDD");
			TextField wordCheckField = new TextField();
			wordCheckField.setPromptText("Type a sentence and see if the words are splled correctly");
			Button checkWordBtn = new Button("Check Spelling");
			Button findPriceBtn = new Button("Find Price");
			Button generateBtn = new Button("Generate");
			
			database.add(showGraph, 1, 3);
			database.add(analyze1, 1,2);
			database.add(analyze2, 1, 4);
			database.add(generateBtn, 1, 6);
			database.add(checkWordBtn, 1, 8);
			database.add(findPriceBtn, 1, 7);
			database.add(menuBar, 0, 0);
	        database.add(wordField, 0, 2);
	        database.add(sentenceField, 0, 3);
	        database.add(syllableField, 0, 4);
	        database.add(fleschField, 0, 5);
	        database.add(wordNumTextField, 0, 6);
	        database.add(dateField, 0, 7);
	        database.add(wordCheckField, 0, 8);
	        
			////////////////
			
		        //defining the axes
		        final NumberAxis xAxis = new NumberAxis();
		        final NumberAxis yAxis = new NumberAxis();
		        xAxis.setLabel("Percentage");
		       
		        //creating the chart
		        final LineChart<Number,Number> lineChart = 
		                new LineChart<Number,Number>(xAxis,yAxis);
		                
		        lineChart.setTitle("Big-O");
		        //defining a series
		        XYChart.Series threeLoopData = new XYChart.Series();
		        XYChart.Series oneLoopData = new XYChart.Series();
		        threeLoopData.setName("Three Loops");
		        oneLoopData.setName("One Loop");
		       // backBtn = new Button("Back");
		     
			////////////////
		        lineChart.getData().addAll(oneLoopData,threeLoopData);
		        //Scene graphS = new Scene(lineChart,500,250);
		        database.add(lineChart, 0,9);
		        Scene scene = new Scene(database, 700,700);
				primaryStage.setScene(scene);
				primaryStage.show();
			
			exitMenuItem.setOnAction(actionEvent -> Platform.exit());
			
			//Reset Everything.
			newMenuItem.setOnAction(new EventHandler<ActionEvent>()  
			{
			    @Override 
			    public void handle(ActionEvent e) 
			    {
			    	multFile.clear();
			    	textArea.clear();
			    	wordField.clear();
					sentenceField.clear();
					syllableField.clear();
					fleschField.clear();
					timeArray.clear();
					timeArray2.clear();
					lineChart.getData().clear();
					oneLoopData.getData().clear();
					threeLoopData.getData().clear();
					wordNumTextField.clear();
					finalT = 0;
					finalT2 =0;
					wordCheckField.clear();
					dateField.clear();
					xScale = 10;
					
					
			    }
			}
			);
			
			//Save the text area
			
			save2MenuItem.setOnAction(new EventHandler<ActionEvent>()  
			{
			    @Override 
			    public void handle(ActionEvent e) 
			    {
			    	
			    	try(  PrintWriter out = new PrintWriter( "output/textArea.txt" )  ){
					    out.println( textArea.getText() );
					} catch (FileNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
			    }
			}
			);
			
			//Open the file(s)
			
			openMenuItem.setOnAction(new EventHandler<ActionEvent>() 
			{
				@Override
				public void handle(final ActionEvent e) {
				List<File> list = fileChooser.showOpenMultipleDialog(primaryStage);
			    	if (list != null) 
			    	{
			    		for (int k = 0; k < list.size(); k++) 
			    		{
			    			multFile.add(list.get(k).getName());
			            }
			        }
			                }
			            });
			
			
			//Analyze with three loops *WayOne.Java*
			
			analyze1.setOnAction(new EventHandler<ActionEvent>()  
			{
			    @Override 
			    public void handle(ActionEvent e) 
			    {
			    	wordField.clear();
					sentenceField.clear();
					syllableField.clear();
					fleschField.clear();
					textArea.appendText("\nThree Loops\n");
			    	for(int i = 0; i < multFile.size(); i++)
			    	{
			    		String everything = "";
			    	try {
						BufferedReader br = new BufferedReader(new FileReader("inputData/"+multFile.get(i)));
						 StringBuilder sb = new StringBuilder();
						   String line = br.readLine();
						    while (line != null) {
						        sb.append(line);
						        sb.append("\n");
						        line = br.readLine();
						    }
						    everything = sb.toString();
						}
			    	catch (FileNotFoundException e1) {
						
						e1.printStackTrace();
					} catch (IOException e1) {
						
						e1.printStackTrace();
					}
			    	
			    	WayOne file1 = new WayOne(everything);
			    	long startTime = System.currentTimeMillis();
			    	textArea.appendText("\nFile: "+multFile.get(i) +"\nWords: " + file1.getNumOfWords()+
			    			"\nSentences: " + file1.getNumOfSentences()
			    			+ "\nSyllables: " + file1.getNumOfSyl()+ 
			    			"\nFlesch Score: " + file1.getFleschScore()+ "\n");
			    	long endTime   = System.currentTimeMillis();
					long totalTime = endTime - startTime;
					timeArray.add(totalTime);
					finalT = totalTime + totalTime; 
					
					wordField.appendText(" ["+Double.toString(file1.getNumOfWords())+"] ");
					sentenceField.appendText(" ["+Double.toString(file1.getNumOfSentences())+"] ");
					syllableField.appendText(" ["+Double.toString(file1.getNumOfSyl())+"] ");
					fleschField.appendText(" ["+Double.toString(file1.getFleschScore())+"] ");
			    	
			    	}
			    	textArea.appendText("\nTotal Time Three Loops: " + finalT);
			    }
			}
			);
			
			//Get and print the words on the TextArea
			
			wordMenuItem.setOnAction(new EventHandler<ActionEvent>()  
			{
			    @Override 
			    public void handle(ActionEvent e) 
			    {
			    	
			    	textArea.setText(wordField.getText() + "\n");
			    }
			}
			);
			
			//Get and print the sentences on the TextArea
			
			sentencesMenuItem.setOnAction(new EventHandler<ActionEvent>()  
			{
			    @Override 
			    public void handle(ActionEvent e) 
			    {
			    	
			    	textArea.setText(sentenceField.getText() + "\n");
			    }
			}
			);
			
			//Get and print the syllables on the TextArea
			
			syllableMenuItem.setOnAction(new EventHandler<ActionEvent>()  
			{
			    @Override 
			    public void handle(ActionEvent e) 
			    {
			    	
			    	textArea.setText(syllableField.getText() + "\n");
			    }
			}
			);
			
			//Get and print the FleschScore on the TextArea
			
			fleschMenuItem.setOnAction(new EventHandler<ActionEvent>()  
			{
			    @Override 
			    public void handle(ActionEvent e) 
			    {
			    	
			    	textArea.setText(fleschField.getText() + "\n");
			    }
			}
			);
		
			//Show the Big-O Time graph
			
			showGraph.setOnAction(new EventHandler<ActionEvent>() {
		        @Override
		        public void handle(ActionEvent t) 
		        {
		        	
		        	if(lineChart.getData().isEmpty())
		        	{
		        		lineChart.getData().addAll(oneLoopData,threeLoopData);
		        	}
		        	if(timeArray.isEmpty())
		        	{
		        		textArea.appendText("\nNo Data Analyze First\n");
		        	}
		        	else
		        	{
		        	//primaryStage.setScene(graphS);
		        	int i = 0;
				        while(i < timeArray.size())
				        {
				        	threeLoopData.getData().add(new XYChart.Data(xScale,timeArray.get(i)));
				        	oneLoopData.getData().add(new XYChart.Data(xScale,timeArray2.get(i)));
				        	xScale = xScale+ 10;
				        	i++;
				        
				        } 
		        	}//end action
		    }});
			
			//Save the counts
			
			saveCountMenuItem.setOnAction(new EventHandler<ActionEvent>()  
			{
			    @Override 
			    public void handle(ActionEvent e) 
			    {
			    	
			    	 
					    	
					    	try(  PrintWriter out = new PrintWriter( "output/results.txt" )  )
					    	{
							    out.println("Words: " +wordField.getText() + "\n"+ "Sentences: "+ sentenceField.getText() + "\n"
							    		+ "Syllables: "+syllableField.getText() + "\n" + "Flesch Scrore: " +fleschField.getText() + "\n");
							} catch (FileNotFoundException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
					    
					}
			    	
			    
			}
			);
			
			/**
			 * The One Loop Analyzer
			 */
			
			analyze2.setOnAction(new EventHandler<ActionEvent>()  
			{
			    
				@Override 
			    public void handle(ActionEvent e) 
			    {
					wordField.clear();
					sentenceField.clear();
					syllableField.clear();
					fleschField.clear();
					textArea.appendText("\nOne Loop\n");
			    	for(int i = 0; i < multFile.size(); i++)
			    	{
			    		String everything = "";
			    	try {
						BufferedReader br = new BufferedReader(new FileReader("inputData/"+multFile.get(i)));
						 StringBuilder sb = new StringBuilder();
						   String line = br.readLine();
						    while (line != null) {
						        sb.append(line);
						        sb.append("\n");
						        line = br.readLine();
						    }
						    everything = sb.toString();
						}
			    	catch (FileNotFoundException e1) {
						
						e1.printStackTrace();
					} catch (IOException e1) {
						
						e1.printStackTrace();
					}
			    	
			    	OneLoop file2 = new OneLoop(everything);
			    	long startTime = System.currentTimeMillis();
			    	file2.getTokens();
			    	long endTime   = System.currentTimeMillis();
					long totalTime = endTime - startTime;
					timeArray2.add(totalTime);
			    	textArea.appendText("\nFile: "+multFile.get(i)+"\nWords: " + file2.getNumOfWords()+
			    			"\nSentences: " + file2.getNumOfSentences()
			    			+ "\nSyllables: " + file2.getNumOfSyllables()+ 
			    			"\nFlesch Score: " + file2.getFleschScore()+ "\n");
			    	finalT2 = totalTime + totalTime; 
			    	
			    	
			    	wordField.appendText(" ["+Double.toString(file2.getNumOfWords())+"] ");
					sentenceField.appendText(" ["+Double.toString(file2.getNumOfSentences())+"] ");
					syllableField.appendText(" ["+Double.toString(file2.getNumOfSyllables())+"] ");
					fleschField.appendText(" ["+Double.toString(file2.getFleschScore())+"] ");
			    	}
			    	textArea.appendText("\nTotal Time One Loop: "+finalT2);
			    }
			}
			);
			
			/**
			 * Put in how many words you want to have in the TextArea, it also randomly takes a word
			 * from the file chosen and works with it to generate the text
			 * @ textEditor/MarkovGenerator.java & textEditor/MarkovInterface.java
			 */
			generateBtn.setOnAction(new EventHandler<ActionEvent>()  
			{
			    @Override 
			    public void handle(ActionEvent e) 
			    {
			    	if(!multFile.isEmpty()||!wordNumTextField.getText().trim().isEmpty())
			    	
			    	for(int i = 0; i < multFile.size(); i++)
			    	{
			    		String genString = "";
			    	try {
						BufferedReader br = new BufferedReader(new FileReader("inputData/"+multFile.get(i)));
						 StringBuilder sb = new StringBuilder();
						   String line = br.readLine();
						    while (line != null) {
						        sb.append(line);
						        sb.append("\n");
						        line = br.readLine();
						    }
						    genString = sb.toString();
						}
			    	catch (FileNotFoundException e1) {
						
						e1.printStackTrace();
					} catch (IOException e1) {
						
						e1.printStackTrace();
					}
			    	
			    	WayOne genF = new WayOne(genString);
			    	
			    	MarkovGenerator gen = new MarkovGenerator(new Random((long) genF.getNumOfWords()));
			    	gen.addText(genString);
			    		int howManyWords = Integer.parseInt(wordNumTextField.getText());
			    		textArea.setText(gen.generateText(howManyWords));
			    	
			    	}//end loop	
			    	else
			    	{
			    		textArea.setText("Make sure you picked a File to generate\nand\nentered how many words you want to generate.");
			    	}
			    }
			});
			
			/**
			 * Saves the generated text
			 */
			
			saveMenuItem.setOnAction(new EventHandler<ActionEvent>()  
			{
			    @Override 
			    public void handle(ActionEvent e) 
			    {
			    	
			    	try(  PrintWriter out = new PrintWriter( "output/GeneratedText.txt" )  ){
					    out.println( textArea.getText() );
					} catch (FileNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
			    }
			}
			);
			
			/**
			 * Finds the price with the date
			 */
			
			findPriceBtn.setOnAction(new EventHandler<ActionEvent>()  
			{
			    @Override 
			    public void handle(ActionEvent e) 
			    {
			    	
			    	int key = Integer.parseInt(dateField.getText());
			    	
			    	long startTime = System.currentTimeMillis();
			    	xNode found = theTree.find(key);
			    	
					
			    	if(found != null) {
						StringBuilder str = new StringBuilder(Integer.toString(key));
						int idx = str.length() - 4;
						int idx2 = str.length() - 1;
						str.insert(idx, "-");
						str.insert(idx2, "-");   
					
						
						textArea.setText("Date: " + str + " Price: $"+ theTree.find(key).dData);
						
					} 
					else 
					{
						textArea.setText("Sorry, that date isn't avaliable!");
					}
					long endTime   = System.currentTimeMillis();
			    	long timeF = endTime - startTime;
			    	textArea.appendText("\nTime in MiliSeconds: "+timeF);
				}
			    	
			    
			}
			);
			
			
			/**
			 * Checks to see if the word entered in the text field
			 * is spelled correctly. 
			 */
			
			checkWordBtn.setOnAction(new EventHandler<ActionEvent>()  
			{
			    @Override 
			    public void handle(ActionEvent e) 
			    {
			    	ArrayList<Long> timeHash = new ArrayList<Long>();
			    	ArrayList<String> hashList = new ArrayList<String>();
			    	hashList.clear();
			    	String s = wordCheckField.getText(); 
			    	textArea.clear();
			    	s = s.replaceAll("\\s+", " ");
			    	s = s.replaceAll("[.,!?\"]", "");
			    	String[] arr = s.split(" ");    
			    	for ( String ss : arr) 
			    	{
			    		hashList.add(ss.toLowerCase());
			    	}
			    	for(int t = 0; t < hashList.size(); t++)
			    	{
			    		
			    	if(hash.containsValue(hashList.get(t)))
			    	{
			    		
			        textArea.appendText("Yes. " + hashList.get(t) + " is spelled correctly.\n");
			        }
			    	else {
			        	 textArea.appendText("No. \"" + hashList.get(t) + "\" is not spelled correctly.\n");
			        	}
			    	
			    	 }
			    	
			    }
			}
			);
			
	}
	/**
	 * Loads the Java HashTable with the Dictionary.Txt
	 */
	
	public static void loadHash()
	{
		
		
		try{
	 		   
 		    BufferedReader rd = new BufferedReader( new FileReader ("inputData/dictionary.txt"));
 		    String line;

 		    int i = 0;
 		    while ((line = rd.readLine()) != null){
 		        
 		    	hash.put(i, line.toLowerCase().trim());
 		        i++;
 		    }
 		  
 		}catch(FileNotFoundException ek){}catch (IOException ek) {}
 		
    }
	
	/**
	 * Load Tree with DJIA dates and prices
	 */
	
	public static void loadTree()
	{
		ArrayList<String> thelist = new ArrayList<String>();
		ArrayList<String> datesList = new ArrayList<String>();
		ArrayList<String> priceList = new ArrayList<String>();
		
		try{
	           BufferedReader buf = new BufferedReader(new FileReader("inputData/shuffledDJIA.txt"));
	           ArrayList<String> words = new ArrayList<>();
	           String lineJustFetched = null;
	           String[] wordsArray;

	           while(true){
	               lineJustFetched = buf.readLine();
	               if(lineJustFetched == null){  
	                   break; 
	               }else{
	                   wordsArray = lineJustFetched.split("\\s+");
	                   for(String each : wordsArray){
	                       if(each.contains(".")){
	                    	   priceList.add(each);
	                       }
	                       else
	                       {
	                    	   datesList.add(each.replaceAll("[\\s\\-()]", ""));
	                       }
	                   }
	               }
	           }
	      
	   	 

	            buf.close();

	        }catch(Exception eo){
	            eo.printStackTrace();
	        }
	     for(int n = 0; n < datesList.size();n++)
	   		{
	   			theTree.insert(Integer.parseInt(datesList.get(n)), priceList.get(n));
	   		}
	}
	
	
	
	public static void main(String[] args) 
	{
		Application.launch(args);
	}
}
